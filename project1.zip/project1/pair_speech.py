import pandas as pd
from pathlib import Path

# =======================
# 0. 參數設定
# =======================

BASE_PATH = Path("./wordnet_data")

THESAURUS_FILE = "WordnetThesaurus.csv"   # 全部單字來源
ADJ_FILE       = "WordnetAdjectives.csv"
ADV_FILE       = "WordnetAdverbs.csv"
NOUN_FILE      = "WordnetNouns.csv"
VERB_FILE      = "WordnetVerbs.csv"

WORD_COL_INDEX = 0   # 每個 CSV 裡「單字」在第幾欄（0 表示第一欄）


# =======================
# 1. 讀 Thesaurus，取得字典 words
# =======================

def load_words():
    df = pd.read_csv(BASE_PATH / THESAURUS_FILE)
    # 取出單字欄，轉小寫，去掉 NaN
    words = (
        df.iloc[:, WORD_COL_INDEX]
        .dropna()
        .astype(str)
        .str.lower()
    )

    # 只保留純英文字母
    words = words[words.str.isalpha()]

    # 去重複
    words = words.drop_duplicates().tolist()
    return words


# =======================
# 2. 建立 word -> 詞性 的字典，只保留 adj/adv/n/v
# =======================

def load_pos_dict():
    pos_dict = {}

    files = [
        (ADJ_FILE,  "adj"),
        (ADV_FILE,  "adv"),
        (NOUN_FILE, "n"),
        (VERB_FILE, "v"),
    ]

    for filename, tag in files:
        df = pd.read_csv(BASE_PATH / filename)
        words = (
            df.iloc[:, WORD_COL_INDEX]
            .dropna()
            .astype(str)
            .str.lower()
        )
        words = words[words.str.isalpha()]
        for w in words:
            # 一個字可能有多種詞性，這裡保留「第一個遇到的」當代表
            if w not in pos_dict:
                pos_dict[w] = tag

    return pos_dict


# =======================
# 3. 找出所有 (word, sub-word) 配對
#    條件：
#    - sub 在 word 的中間（不是開頭/結尾）
#    - sub 長度 >= 3
#    - sub 必須也在字典裡
# =======================

def find_subword_pairs(words):
    word_set = set(words)
    pairs = []          # (word, sub)
    seen = set()        # 用來避免重複 (word, sub)

    for w in words:
        L = len(w)
        # 最短要 5 才能在中間塞一個長度 >=3 的 sub
        if L < 5:
            continue

        # 在 w[1:-1] 之間找所有長度 >=3 的 substring
        for start in range(1, L - 1):
            for end in range(start + 3, L):   # end 是「不含」，所以 < L
                s = w[start:end]
                if s in word_set:
                    key = (w, s)
                    if key not in seen:
                        seen.add(key)
                        pairs.append(key)

    return pairs


# =======================
# 4. 主流程
# =======================

def main():
    print("載入字典 words ...")
    words = load_words()
    print(f"總共有 {len(words)} 個字。")

    print("建立 word -> 詞性 的對應 ...")
    pos_dict = load_pos_dict()
    print(f"有詞性的單字數量：{len(pos_dict)}")

    print("搜尋所有 (word, sub-word) 配對 ...（這一步比較久）")
    pairs = find_subword_pairs(words)
    print(f"找到 {len(pairs)} 組 (word, sub-word) 配對。")

    # 轉成 DataFrame，存全部配對（不管有沒有詞性）
    df_pairs_all = pd.DataFrame(pairs, columns=["word", "sub"])
    df_pairs_all.to_csv("word_sub_pairs_all.csv", index=False)
    print("已輸出：word_sub_pairs_all.csv")

    # 加上詞性欄位，只保留 adj/adv/n/v 的組合
    word_pos_list = []
    sub_pos_list = []
    keep_rows = []

    allowed = {"adj", "adv", "n", "v"}

    for w, s in pairs:
        w_pos = pos_dict.get(w)
        s_pos = pos_dict.get(s)
        if (w_pos in allowed) and (s_pos in allowed):
            keep_rows.append((w, s, w_pos, s_pos))

    df_pos_pairs = pd.DataFrame(
        keep_rows,
        columns=["word", "sub", "word_pos", "sub_pos"]
    )
    df_pos_pairs.to_csv("word_sub_pos_pairs.csv", index=False)
    print("已輸出：word_sub_pos_pairs.csv")

    # 5. 每個 word 的 sub-word 數量（做直方圖 / 箱型圖會用到）
    df_counts = (
        df_pos_pairs
        .groupby("word")
        .size()
        .reset_index(name="subword_count")
    )
    df_counts.to_csv("word_sub_counts.csv", index=False)
    print("已輸出:word_sub_counts.csv")

    # 6. 詞性 × 詞性 交叉表（Heatmap 用）
    cross = pd.crosstab(df_pos_pairs["word_pos"], df_pos_pairs["sub_pos"])
    cross.to_csv("pos_heatmap_table.csv")
    print("已輸出:pos_heatmap_table.csv")

    print("全部完成！")


if __name__ == "__main__":
    main()

