"""
Sub-word (字中字) 分析程式
------------------------

需要先準備：
- WordnetNouns.csv
- WordnetVerbs.csv
- WordnetAdjectives.csv
- WordnetAdverbs.csv

放在跟這支程式同一個資料夾，或修改 BASE_PATH 指到正確路徑。

安裝套件：
    pip install pandas matplotlib seaborn
"""

import os
import re
import collections

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# ==========================
#  1. 參數設定
# ==========================

# CSV 檔案所在的資料夾
BASE_PATH = "."

# 輸出圖檔的資料夾
OUTPUT_DIR = "./plots"


# ==========================
#  2. 工具函式：讀取與清洗
# ==========================

def load_wordnet_dict(base_path=BASE_PATH):
    """
    讀取 WordNet 的四個詞性檔案，回傳：
    - word_pos: dict, key=單字, value=詞性("noun","verb","adj","adv")

    規則：
    - 只保留「全部由英文字母組成」的條目 (用正則 [A-Za-z]+)
    - 全部轉成小寫
    - 若同一個字在多個詞性出現，只保留先讀到的那一個
      （作業要求：多詞性只取一個代表）
    """
    files = [
        ("WordnetNouns.csv", "noun"),
        ("WordnetVerbs.csv", "verb"),
        ("WordnetAdjectives.csv", "adj"),
        ("WordnetAdverbs.csv", "adv"),
    ]

    word_pos = {}

    for fname, pos in files:
        path = os.path.join(base_path, fname)
        print(f"[INFO] 讀取 {path} (詞性：{pos})")

        df = pd.read_csv(path)

        if "Word" not in df.columns:
            raise ValueError(f"{fname} 中找不到 'Word' 欄位，請檢查檔案格式。")

        for w in df["Word"]:
            if pd.isna(w):
                continue

            # 原始字串
            w_str = str(w)

            # 只保留完全由英文字母組成的單字 (排除空白、標點、數字)
            if not re.fullmatch(r"[A-Za-z]+", w_str):
                continue

            w_clean = w_str.lower()

            # 若同一單字在多個檔案出現，只保留第一次的詞性
            if w_clean not in word_pos:
                word_pos[w_clean] = pos

    print(f"[INFO] 讀取完成，共有 {len(word_pos)} 個不同單字。")
    return word_pos


# ==========================
#  3. 找出所有 sub-word 配對
# ==========================

def find_subwords(word_pos):
    """
    依照專題定義尋找所有 (word, sub-word) 配對。

    條件：
    - sub-word 長度 >= 3
    - sub-word 出現在 word 的中間
      (用 w[1:-1] 來限制，不能用頭或尾)
    - sub-word 也必須出現在字典中 (word_pos 的 key)
    - word != sub-word

    回傳：
    - pairs: list of (word, subword)
    - word_subcount: Counter, key=word, value=該 word 含有多少不同 sub-word
    - subword_counter: Counter, key=subword, value=出現在幾個 word 裡
    """

    words = list(word_pos.keys())
    word_set = set(words)

    pairs = []
    word_subcount = collections.Counter()
    subword_counter = collections.Counter()

    print("[INFO] 開始搜尋 sub-word ...")

    for idx, w in enumerate(words):
        if idx % 5000 == 0 and idx > 0:
            print(f"  已處理 {idx} 個單字...")

        L = len(w)

        # 最小字長：sub-word >=3，且不能用首尾 => 至少 5
        if L < 5:
            continue

        seen_subs = set()

        # i: sub-word 開頭 index (從 1 開始，避開首字)
        # j: sub-word 結尾 index (Python 切片是 [i:j), 所以 j 最多到 L-1)
        for i in range(1, L - 1):
            # j 從 i+3 開始，確保長度 >=3
            for j in range(i + 3, L + 1):
                if j >= L:
                    # 不可以包含最後一個字 (要在中間)
                    break

                s = w[i:j]

                # s 長度一定 >=3，不用再檢查
                if s == w:
                    continue

                if s in word_set and s not in seen_subs:
                    seen_subs.add(s)
                    pairs.append((w, s))

        if seen_subs:
            word_subcount[w] = len(seen_subs)
            for s in seen_subs:
                subword_counter[s] += 1

    print(f"[INFO] 搜尋完成，共找到 {len(pairs)} 組 (word, sub-word) 配對。")
    print(f"[INFO] 共有 {len(word_subcount)} 個 word 至少包含 1 個 sub-word。")
    print(f"[INFO] 共有 {len(subword_counter)} 個不同的 sub-word。")

    return pairs, word_subcount, subword_counter


# ==========================
#  4. 建立分析用 DataFrame
# ==========================

def build_dataframes(word_pos, pairs, word_subcount, subword_counter):
    """
    建立：
    - pairs_df: 每一列為一組 (word, subword, word_pos, subword_pos)
    - word_df: 每個 word 的 sub-word 數量與是否有 sub-word
    - sub_df: 每個 sub-word 被幾個 word 使用
    """

    # (1) pair 資料
    pair_rows = []
    for w, s in pairs:
        pair_rows.append({
            "word": w,
            "subword": s,
            "word_pos": word_pos.get(w),
            "subword_pos": word_pos.get(s),
        })
    pairs_df = pd.DataFrame(pair_rows)

    # (2) 每個 word 的統計
    word_rows = []
    for w, pos in word_pos.items():
        cnt = word_subcount.get(w, 0)
        word_rows.append({
            "word": w,
            "pos": pos,
            "subword_count": cnt,
            "has_subword": cnt > 0,
        })
    word_df = pd.DataFrame(word_rows)

    # (3) 每個 sub-word 的統計
    sub_rows = []
    for s, cnt in subword_counter.items():
        sub_rows.append({
            "subword": s,
            "subword_pos": word_pos.get(s),
            "word_count": cnt,
        })
    sub_df = pd.DataFrame(sub_rows)

    print("[INFO] DataFrame 建立完成。")
    print("  pairs_df:", pairs_df.shape)
    print("  word_df:", word_df.shape)
    print("  sub_df :", sub_df.shape)

    return pairs_df, word_df, sub_df


# ==========================
#  5. 畫圖：6 張必做圖
# ==========================

def plot_proportion(word_df, out_dir=OUTPUT_DIR):
    """
    一、比例分析
    1. Pie Chart：有 / 沒有 sub-word 的比例
    2. Bar Chart：各詞性中「有 sub-word」的比例
    """
    os.makedirs(out_dir, exist_ok=True)

    # --- Pie chart ---
    has_sub = word_df["has_subword"].sum()
    total = len(word_df)

    labels = ["Has sub-word", "No sub-word"]
    sizes = [has_sub, total - has_sub]

    plt.figure()
    plt.pie(sizes, labels=labels, autopct="%1.1f%%", startangle=90)
    plt.title("Words with / without sub-word")
    plt.axis("equal")
    plt.savefig(os.path.join(out_dir, "01_pie_has_subword.png"),
                bbox_inches="tight")
    plt.close()

    # --- Bar chart by POS ---
    # 先算每個 POS 中，有 sub-word 的比例
    pos_order = ["noun", "verb", "adj", "adv"]
    pos_prop = (
        word_df.groupby("pos")["has_subword"]
        .mean()
        .reindex(pos_order)
    )

    plt.figure()
    pos_prop.plot(kind="bar")
    plt.ylabel("Proportion with sub-word")
    plt.xlabel("POS")
    plt.title("Proportion of words with sub-word by POS")
    plt.ylim(0, 1)
    plt.savefig(os.path.join(out_dir, "02_bar_pos_proportion.png"),
                bbox_inches="tight")
    plt.close()


def plot_structure(word_df, out_dir=OUTPUT_DIR):
    """
    二、組成結構分析
    1. Histogram：一個 word 有幾個 sub-word
    2. Boxplot：各詞性的 sub-word 數量分佈
    """
    os.makedirs(out_dir, exist_ok=True)

    # 只看有至少 1 個 sub-word 的 word
    df_nonzero = word_df[word_df["subword_count"] > 0].copy()

    # --- Histogram ---
    max_cnt = int(df_nonzero["subword_count"].max())
    bins = range(1, max_cnt + 2)

    plt.figure()
    df_nonzero["subword_count"].plot(kind="hist", bins=bins, align="left")
    plt.xlabel("Number of sub-words in a word")
    plt.ylabel("Word count")
    plt.title("Distribution of sub-word counts per word")
    plt.xticks(range(1, max_cnt + 1))
    plt.savefig(os.path.join(out_dir, "03_hist_subword_counts.png"),
                bbox_inches="tight")
    plt.close()

    # --- Boxplot by POS ---
    pos_order = ["noun", "verb", "adj", "adv"]
    plt.figure()
    sns.boxplot(
        data=df_nonzero,
        x="pos",
        y="subword_count",
        order=pos_order,
    )
    plt.xlabel("POS")
    plt.ylabel("Number of sub-words")
    plt.title("Sub-word count distribution by POS")
    plt.savefig(os.path.join(out_dir, "04_box_subword_by_pos.png"),
                bbox_inches="tight")
    plt.close()


def plot_frequency(sub_df, out_dir=OUTPUT_DIR, top_k=10):
    """
    三、頻率分析
    - 畫出 Top K sub-word 的橫向長條圖
    """
    os.makedirs(out_dir, exist_ok=True)

    top = (
        sub_df.sort_values("word_count", ascending=False)
        .head(top_k)
        .sort_values("word_count")  # 讓圖從少到多往上長
    )

    plt.figure()
    plt.barh(top["subword"], top["word_count"])
    plt.xlabel("Number of words containing this sub-word")
    plt.ylabel("Sub-word")
    plt.title(f"Top {top_k} most frequent sub-words")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "05_barh_top_subwords.png"),
                bbox_inches="tight")
    plt.close()


def plot_pos_heatmap(pairs_df, out_dir=OUTPUT_DIR):
    """
    四、詞性關聯分析 (Heatmap)
    - X: sub-word POS
    - Y: word POS
    - color: 次數
    """
    os.makedirs(out_dir, exist_ok=True)

    pos_order = ["noun", "verb", "adj", "adv"]

    ctab = pd.crosstab(
        pairs_df["word_pos"],
        pairs_df["subword_pos"],
    ).reindex(index=pos_order, columns=pos_order)

    plt.figure()
    sns.heatmap(ctab, annot=True, fmt="d")
    plt.title("POS relation: word vs sub-word")
    plt.xlabel("Sub-word POS")
    plt.ylabel("Word POS")
    plt.savefig(os.path.join(out_dir, "06_heatmap_pos_relation.png"),
                bbox_inches="tight")
    plt.close()


# ==========================
#  6. 主流程
# ==========================

def main():
    # 讀取 & 預處理
    word_pos = load_wordnet_dict(BASE_PATH)

    # 尋找所有 (word, sub-word)
    pairs, word_subcount, subword_counter = find_subwords(word_pos)

    # 建立 DataFrame
    pairs_df, word_df, sub_df = build_dataframes(
        word_pos, pairs, word_subcount, subword_counter
    )

    # 輸出簡單文字 summary（之後可以貼到簡報）
    total_words = len(word_df)
    words_with_sub = word_df["has_subword"].sum()
    ratio = words_with_sub / total_words * 100

    print("\n========== Summary ==========")
    print(f"字典總單字數：{total_words}")
    print(f"至少包含 1 個 sub-word 的單字數：{words_with_sub}")
    print(f"比例：約 {ratio:.2f}%")
    print(f"不同的 sub-word 數量：{len(sub_df)}")
    print("================================\n")

    # 畫圖
    plot_proportion(word_df, OUTPUT_DIR)
    plot_structure(word_df, OUTPUT_DIR)
    plot_frequency(sub_df, OUTPUT_DIR, top_k=10)
    plot_pos_heatmap(pairs_df, OUTPUT_DIR)

    print(f"[INFO] 圖片已輸出到資料夾：{OUTPUT_DIR}")
    print("  01_pie_has_subword.png")
    print("  02_bar_pos_proportion.png")
    print("  03_hist_subword_counts.png")
    print("  04_box_subword_by_pos.png")
    print("  05_barh_top_subwords.png")
    print("  06_heatmap_pos_relation.png")


if __name__ == "__main__":
    main()