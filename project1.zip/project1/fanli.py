word = "abnormality"
for i in range(1,len(word)-3):
    for j in range(i+3,len(word)):
        print(word[i:j])
