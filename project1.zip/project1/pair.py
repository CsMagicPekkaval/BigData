import pandas as pd
import time
start = time.time()
# ===== 1. 路徑＆檔名設定 =====
BASE_PATH = "./wordnet_data"          # 放 CSV 的資料夾
FILE = "WordnetThesaurus.csv"         # 目前處理的檔案

MIN_LEN = 3                           # sub-word 最短長度
OUTPUT_CSV = "try.csv"


# ===== 2. 讀取 CSV，整理成 (word, length) =====
df = pd.read_csv(f"{BASE_PATH}/{FILE}")

# 用 dict 先去掉重複單字：word -> length
word_len_dict = {}

for i in range(len(df)):
    word = df.iloc[i, 0]      # 第一欄：單字
    length = df.iloc[i, 1]    # 第二欄：字數（長度）

    if pd.isna(word):
        continue

    word = str(word).lower()

    # 只保留純英文字
    if not word.isalpha():
        continue

    # 若第二欄不是數字就用 len(word)
    try:
        length = int(length)
    except Exception:
        length = len(word)

    if word in word_len_dict:
        continue

    word_len_dict[word] = length

word_len_list = list(word_len_dict.items())
word_set = set(word_len_dict.keys())

print(f"[INFO] 不重複單字數量：{len(word_len_list)}")


# ===== 3. 找出所有 (word, sub-word) 配對 =====
raw_pairs = []

for word, Lw in word_len_list:
    mid_len = Lw - 2
    if mid_len < MIN_LEN:
        continue

    mid = word[1:-1]
    seen_subs = set()

    for s, Ls in word_len_list:
        if s == word:
            continue
        if Ls < MIN_LEN:
            continue
        if Ls > mid_len:
            continue

        if s in mid and s not in seen_subs:
            seen_subs.add(s)
            raw_pairs.append((word, s))

print(f"[INFO] 找到 {len(raw_pairs)} 組 (word, sub-word) 配對（含重複）")


# ===== 4. 去重複 =====
pairs_unique = list(set(raw_pairs))
print(f"[INFO] 去重後剩 {len(pairs_unique)} 組配對。")

# 只保留 (word, subword)
rows_sorted = sorted(pairs_unique, key=lambda x: (x[0], x[1]))


# ===== 5. 輸出 CSV =====
pairs_df = pd.DataFrame(
    rows_sorted,
    columns=["word", "subword"]
)

pairs_df.to_csv(OUTPUT_CSV, index=False, encoding="utf-8")

print(f"[INFO] 已輸出 CSV:{OUTPUT_CSV}")

end = time.time()
print("執行時間：", end - start, "秒")
