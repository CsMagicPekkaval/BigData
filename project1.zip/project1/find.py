import pandas as pd

# ===== 1. 路徑＆檔名設定 =====
BASE_PATH = "./wordnet_data"          # CSV 資料夾
FILE = "Wordnetnouns.csv"        # 要處理哪個檔案就改這個

MIN_LEN = 3                           # sub-word 最短長度
OUTPUT_CSV = "n.csv"


# ===== 2. 讀取 CSV，整理成 (word, length) =====
df = pd.read_csv(f"{BASE_PATH}/{FILE}")

# 用 dict 去掉重複單字：word -> length
word_len_dict = {}

for i in range(len(df)):
    word = df.iloc[i, 0]      # 第一欄：單字
    length = df.iloc[i, 1]    # 第二欄：字數（長度）

    if pd.isna(word):
        continue

    word = str(word).lower()

    # 只保留純英文字（避免空格、符號）
    if not word.isalpha():
        continue

    # 長度欄如果不是數字，就用 len(word)
    try:
        length = int(length)
    except Exception:
        length = len(word)

    # 同一個單字只保留第一筆
    if word in word_len_dict:
        continue

    word_len_dict[word] = length

# 轉回 list & set
word_len_list = list(word_len_dict.items())
word_set = set(word_len_dict.keys())

print(f"[INFO] 不重複單字數量：{len(word_len_list)}")


# ===== 3. 用「枚舉 substring」方法找 sub-word =====
raw_pairs = []

for word, Lw in word_len_list:
    mid_len = Lw - 2
    if mid_len < MIN_LEN:
        continue

    mid = word[1:-1]      # 中間那一段
    seen_subs = set()     # 同一個 word 內避免重複 subword

    # 在 mid 中枚舉所有長度 >= MIN_LEN 的子字串
    for i in range(len(mid)):
        for j in range(i + MIN_LEN, len(mid) + 1):
            sub = mid[i:j]

            # 必須是字典裡的字，且沒記錄過
            if sub in word_set and sub not in seen_subs:
                seen_subs.add(sub)
                raw_pairs.append((word, sub))

print(f"[INFO] 找到 {len(raw_pairs)} 組 (word, sub-word) 配對")


# ===== 4. 去重複，輸出成 CSV =====
pairs_unique = list(set(raw_pairs))
print(f"[INFO] 去重後剩 {len(pairs_unique)} 組配對")

# 排序：先照 word，再照 subword
pairs_sorted = sorted(pairs_unique, key=lambda x: (x[0], x[1]))

pairs_df = pd.DataFrame(pairs_sorted, columns=["word", "subword"])
pairs_df.to_csv(OUTPUT_CSV, index=False, encoding="utf-8")

print(f"[INFO] 已輸出 CSV:{OUTPUT_CSV}")
